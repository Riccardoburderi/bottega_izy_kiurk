<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title>Bottega Izy e Kiurk</title>

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.12.1/css/bootstrap-select.css" />
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.12.1/js/bootstrap-select.js"></script>
    <script src="https://www.youtube.com/iframe_api"></script>
 <script src="https://cdn.rawgit.com/labnol/files/master/yt.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
        <link href="//db.onlinewebfonts.com/c/d4f498023801dd6ec85ab70468df2c03?family=aliens+and+cows" rel="stylesheet" type="text/css"/>
      
    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <style>
    @import  url(//db.onlinewebfonts.com/c/d4f498023801dd6ec85ab70468df2c03?family=aliens+and+cows);
        @font-face {font-family: "aliens and cows"; src: url("//db.onlinewebfonts.com/t/d4f498023801dd6ec85ab70468df2c03.eot"); src: url("//db.onlinewebfonts.com/t/d4f498023801dd6ec85ab70468df2c03.eot?#iefix") format("embedded-opentype"), url("//db.onlinewebfonts.com/t/d4f498023801dd6ec85ab70468df2c03.woff2") format("woff2"), url("//db.onlinewebfonts.com/t/d4f498023801dd6ec85ab70468df2c03.woff") format("woff"), url("//db.onlinewebfonts.com/t/d4f498023801dd6ec85ab70468df2c03.ttf") format("truetype"), url("//db.onlinewebfonts.com/t/d4f498023801dd6ec85ab70468df2c03.svg#aliens and cows") format("svg"); }
    .scroll::-webkit-scrollbar { width: 0 !important }
    .scroll { overflow: -moz-scrollbars-none; }
        
.tooltip {
  position: relative;  
  display: block;
  opacity: 1;
  margin-right: 50px;
}

/* Tooltip text */

.tooltip .tooltiptext{
    visibility: hidden;
    width: 200px;
                background-color: rgba(123, 131, 121, 0.8); 
                margin-top: 20px; 
                margin-bottom: 20px;
                border: solid 1px #363d35!important;  
                
                font-family: Georgia, 'Times New Roman', Times, serif;

                text-shadow: 1px 1px 5px #363d35!important;
                color: black!important;
                text-align: center;
                padding: 5px 0;
                border-radius: 6px;
                -webkit-box-shadow: 1px 2px 2px 1px #363d35!important; 
                box-shadow: 1px 2px 2px 1px #363d35!important;
               
                /* Position the tooltip text - see examples below! */
                position: absolute;
                z-index: 1;
                width: 200px;
                top: 50%;
                left: 50%; 
                margin-left: -60px;
}
.tooltip:hover .tooltiptext {
  visibility: visible;
}
a { text-decoration: none } 
        a:hover { text-decoration: none }
        @font-face {
            font-family: alien;
            src: url(./../../public/css/aliensandcows_trial.ttf);
        }

    </style>
</head>
<body style="
        background-image: url(img/TEXTURESCURA.png);
        background-repeat:repeat;">
    <main style="min-width:50%">
        <?php echo $__env->yieldContent('content'); ?>
    </main>
</body>
</html>
<?php /**PATH C:\Users\ricca\Desktop\Bottega-izi-GIT\bottega_izy_kiurk\resources\views/layouts/bott_layout.blade.php ENDPATH**/ ?>