

<?php $__env->startSection('content'); ?>

<style>
    .container {
    }
    .push-top {
      margin-top: 50px;
      max-width:300px;
    }
    .table{
        font-size:30px;
    }
    #myInput {
  background-image: url('/css/searchicon.png'); /* Add a search icon to input */
  background-position: 10px 12px; /* Position the search icon */
  background-repeat: no-repeat; /* Do not repeat the icon image */
  width: 100%; /* Full-width */
  font-size: 16px; /* Increase font-size */
  padding: 12px 20px 12px 40px; /* Add some padding */
  border: 1px solid #ddd; /* Add a grey border */
  margin-bottom: 12px; /* Add some space below the input */
}

#myTable {
  border-collapse: collapse; /* Collapse borders */
  width: 100%; /* Full-width */
  border: 1px solid #ddd; /* Add a grey border */
  font-size: 18px; /* Increase font-size */
}

#myTable th, #myTable td {
  text-align: left; /* Left-align text */
  padding: 12px; /* Add padding */
}

#myTable tr {
  /* Add a bottom border to all table rows */
  border-bottom: 1px solid #ddd;
}

#myTable tr.header, #myTable tr:hover {
  /* Add a grey background color to the table header and on hover */
  background-color: #f1f1f1;
}
</style>
<div class="column">
    <div class="col-lg-4 col-md-4 col-sm-4">
        <div class="card push-top">
            <div class="card-header">
                Aggiungi Animale
            </div>
            <div class="card-body">
                <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div><br />
                <?php endif; ?>
                <form method="post" action="<?php echo e(route('animals.store')); ?>">
                    <div class="form-group">
                        <?php echo csrf_field(); ?>
                        <label for="name">Nome</label>
                        <input type="text" class="form-control" name="name"/>
                    </div>
                    <div class="form-group">
                        <label for="price">Prezzo</label>
                        <input type="text" class="form-control" name="price"/>
                    </div>
                    <div class="form-group">
                        <label for="recipe">Ricetta Personalizzata</label>
                        <input type="text" class="form-control" name="recipe"/>
                    </div>
                    <div class="form-group">
                        <label for="birthday">Data di Nascita</label>
                        <input type="text" class="form-control" name="birthday"/>
                    </div>
                    <!-- <div class="form-group">
                        <strong>Image: not working</strong>
                        <input type="file" id="pic" name="pic" class="form-control"></input>
                    </div> -->
                    <div class="form-group">
                        <label for="image">Immagine</label>
                        <input type="text" class="form-control" name="image"/>
                    </div>
                    <div class="form-group">
                        <label for="description">Descrizione Personalizzata</label>
                        <input type="text" class="form-control" name="description"/>
                    </div>
                    <div class="form-group">
                    <label for="subcategory_id">Sottocategoria</label>

                        <input type="text" name="subcategory_id" list="subcategory_id">
                        <datalist id="subcategory_id">
                        <?php $__currentLoopData = $sub; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <option value="<?php echo e($subcategory->id); ?>">
                            <?php echo e($subcategory->name); ?>

                        </option>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </datalist>
                    <button type="submit" class="btn btn-block btn-danger">Crea Animale</button>
                    </div>
                        </div>
                </form>
            </div>
        </div>
    </div>

    <div class="col-lg-8 col-md-8 col-sm-8">
        <div class="push-top">
            <?php if(session()->get('success')): ?>
                <div class="alert alert-success">
                <?php echo e(session()->get('success')); ?>  
                </div><br />
            <?php endif; ?>
            <input type="text" id="myInput" onkeyup="myFunctionSearch()" placeholder="Search for names..">

            <table class="table" id="myTable">
                <thead>
                    <tr class="table-warning">
                    <td>ID</td>
                    <td>Name</td>
                    <td>Prezzo</td>
                    <td>Ricetta personalizzata</td>
                    <td>Compleanno</td>
                    <td>Immagine</td>
                    <td>Descirzione</td>
                    <td>Sottocategoria</td>
                    <td>Vend</td>
                    <td class="text-center">Action</td>
                    </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $animal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $animals): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                        <td><?php echo e($animals->id); ?></td>
                        <td><?php echo e($animals->name); ?></td>
                        <td><?php echo e($animals->price); ?></td>
                        <td><?php echo e($animals->recipe); ?></td>
                        <td><?php echo e($animals->birthday); ?></td>
                        <td><?php echo e($animals->image); ?></td>
                        <td><?php echo e($animals->description); ?></td>
                        <td><?php echo e($animals->subcategory->name); ?></td>
                        <td><?php echo e($animals->venduto); ?></td>
                        <td class="text-center">
                            <a href="<?php echo e(route('animals.edit', $animals->id)); ?>" class="btn btn-primary btn-sm">Edit</a>
                            <form action="<?php echo e(route('animals.destroy', $animals->id)); ?>" method="post" style="display: inline-block">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button class="btn btn-danger btn-sm" type="submit">Delete</button>
                            </form> 
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ricca\Desktop\Bottega-izi-GIT\bottega_izy_kiurk\resources\views/index_animal.blade.php ENDPATH**/ ?>