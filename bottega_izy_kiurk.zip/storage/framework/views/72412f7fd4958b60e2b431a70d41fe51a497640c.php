

<?php $__env->startSection('content'); ?>

<style>
    .container {
    }
    .push-top {
      margin-top: 50px;
      max-width:300px;
    }
</style>
<div class="row">
    <div class="col-lg-4 col-md-4">
    <div class="card push-top">
  <div class="card-header">
    Aggiungi Categoria
  </div>

  <div class="card-body">
    <?php if($errors->any()): ?>
      <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
      </div><br />
    <?php endif; ?>
      <form method="post" action="<?php echo e(route('categories.store')); ?>">
          <div class="form-group">
              <?php echo csrf_field(); ?>
              <label for="name">Nome</label>
              <input type="text" class="form-control" name="name"/>
          </div>
          <div class="form-group">
              <label for="ricetta">Ricetta</label>
              <input type="text" class="form-control" name="ricetta"/>
          </div>
          <button type="submit" class="btn btn-block btn-danger">Crea Categoria</button>
      </form>
  </div>
</div>
    </div>


    <div class="col-lg-8 col-md-8">
    <div class="push-top">
  <?php if(session()->get('success')): ?>
    <div class="alert alert-success">
      <?php echo e(session()->get('success')); ?>  
    </div><br />
  <?php endif; ?>
  <table class="table">
    <thead>
        <tr class="table-warning">
          <td>ID</td>
          <td>Name</td>
          <td>Ricetta</td>
          <td class="text-center">Action</td>
        </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $cat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categories): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
            <td><?php echo e($categories->id); ?></td>
            <td><?php echo e($categories->name); ?></td>
            <td><?php echo e($categories->ricetta); ?></td>
            <td class="text-center">
                <a href="<?php echo e(route('categories.edit', $categories->id)); ?>" class="btn btn-primary btn-sm">Edit</a>
                <form action="<?php echo e(route('categories.destroy', $categories->id)); ?>" method="post" style="display: inline-block">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button class="btn btn-danger btn-sm" type="submit">Delete</button>
                  </form> 
            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
<div>
    </div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ricca\Desktop\Bottega-izi-GIT\bottega_izy_kiurk\resources\views/index_category.blade.php ENDPATH**/ ?>