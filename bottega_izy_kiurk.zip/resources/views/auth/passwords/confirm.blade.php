@extends('layouts.app')

@section('content')
<div class="container">
   nope
</div>
@endsection
